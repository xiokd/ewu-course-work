package cscd212_assignment4;

public interface Dough {
	public String toString();
}
