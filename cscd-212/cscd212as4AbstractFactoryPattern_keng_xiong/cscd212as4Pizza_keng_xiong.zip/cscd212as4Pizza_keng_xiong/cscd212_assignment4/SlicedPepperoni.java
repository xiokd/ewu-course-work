package cscd212_assignment4;

public class SlicedPepperoni implements Pepperoni {
	public String toString() {
		return "Pepperoni";
	}
}
