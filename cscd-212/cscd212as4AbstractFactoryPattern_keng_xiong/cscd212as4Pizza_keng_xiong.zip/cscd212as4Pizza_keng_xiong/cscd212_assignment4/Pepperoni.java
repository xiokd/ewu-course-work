package cscd212_assignment4;

public interface Pepperoni {
	public String toString();
}
