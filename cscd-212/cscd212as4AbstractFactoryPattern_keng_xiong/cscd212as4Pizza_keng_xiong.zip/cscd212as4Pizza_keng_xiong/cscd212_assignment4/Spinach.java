package cscd212_assignment4;

public class Spinach implements Veggies {
	public String toString() {
		return "Spinach";
	}
}
