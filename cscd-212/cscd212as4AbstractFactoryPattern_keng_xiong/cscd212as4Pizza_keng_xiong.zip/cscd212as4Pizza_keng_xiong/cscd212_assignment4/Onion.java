package cscd212_assignment4;

public class Onion implements Veggies {
	public String toString() {
		return "Onion";
	}
}
