public abstract class AbstractFactory {
	protected abstract Shape getShape(String shape);
}
