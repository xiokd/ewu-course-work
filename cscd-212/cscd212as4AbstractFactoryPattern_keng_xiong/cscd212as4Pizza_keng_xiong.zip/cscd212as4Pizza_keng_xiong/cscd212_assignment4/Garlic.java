package cscd212_assignment4;

public class Garlic implements Veggies {
	public String toString() {
		return "Garlic";
	}
}
