package cscd212_assignment4;

import java.util.ArrayList;

public abstract class Pizza {
	String name;
	Dough dough;
	Sauce sauce;
	Veggies veggies[];
	Cheese cheese;
	Pepperoni pepperoni;
	Clams clam;

	ArrayList toppings = new ArrayList();

	abstract void prepare();

	void bake() {
		System.out.println("Back for 25 minutes at 350");
	}

	void cut() {
		System.out.println("Cutting the pizza into diagonal slices");
	}

	void box() {
		System.out.println("Place pizza in offical PizzaStore box");
	}

	public String getName() {
		return name;
	}

	void setName(String name) {
		this.name = name;
	}

	public String toString() {
		String str = name + "\n";
		if(dough != null) {
			str += dough + "\n";
		}
		if(sauce != null) {
			str += sauce + "\n";
		}
		if(cheese != null) {
			str += cheese + "\n";
		}
		if(veggies != null) {
			for(int i = 0; i < veggies.length; i++) {
				str += veggies[i];
				if(i < veggies.length - 1) {
					str += ", ";
				}
			}
			str += "\n";
		}
		if(clam != null) {
			str += clam + "\n";
		}

		if(pepperoni != null) {
			str += pepperoni + "\n";
		}

		return str;
	}


}
