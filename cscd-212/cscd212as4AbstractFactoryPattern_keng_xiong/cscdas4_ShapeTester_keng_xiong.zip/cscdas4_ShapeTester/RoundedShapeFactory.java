public class RoundedShapeFactory extends AbstractFactory {
	protected Shape getShape(String shape) {
		if (shape == null) {
			return null; // Returns null if string is null
		}

		if (shape.equalsIgnoreCase("rounded square") || shape.equalsIgnoreCase("roundedsquare")) {
			return new RoundedSquare();
		} else if (shape.equalsIgnoreCase("rounded rectangle") || shape.equalsIgnoreCase("roundedrectangle")) {
			return new RoundedRectangle();
		}

		return null; // Returns Null if the shape isn't found

	}
}
