package cscd212_assignment4;

public interface Sauce {
	public String toString();
}
