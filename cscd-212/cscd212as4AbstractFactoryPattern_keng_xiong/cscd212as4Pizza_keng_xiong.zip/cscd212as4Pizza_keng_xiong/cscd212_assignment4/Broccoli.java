package cscd212_assignment4;

public class Broccoli implements Veggies {
	public String toString() {
		return "Broccoli";
	}
}
