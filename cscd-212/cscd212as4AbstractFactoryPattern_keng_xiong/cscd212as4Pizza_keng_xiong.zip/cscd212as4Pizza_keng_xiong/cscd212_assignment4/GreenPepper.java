package cscd212_assignment4;

public class GreenPepper implements Veggies {
	public String toString() {
		return "Green Pepper";
	}
}
