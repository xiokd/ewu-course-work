public class AbstractFactoryPatternDemo {

	public static void main(String[] args) {
		String shapeString1 = "Rectangle"; // Assigns shape name as a string
		AbstractFactory factory1 = FactoryProducer.getFactory(shapeString1); // Gets specified factory
		Shape shape1 = factory1.getShape(shapeString1); // Gets shape from factory
		shape1.draw(); // Displays draw message for shape

		String shapeString2 = "Square"; // Assigns shape name as a string
		AbstractFactory factory2 = FactoryProducer.getFactory(shapeString2); // Gets specified factory
		Shape shape2 = factory2.getShape(shapeString2);
		shape2.draw(); // Displays draw message for shape

		String shapeString3 = "Rounded Rectangle"; // Assigns shape name as a string
		AbstractFactory factory3 = FactoryProducer.getFactory(shapeString3); // Gets specified factory
		Shape shape3 = factory3.getShape(shapeString3); // Gets shape from factory
		shape3.draw(); // Displays draw message for shape

		String shapeString4 = "Rounded Square"; // Assigns shape name as a string
		AbstractFactory factory4 = FactoryProducer.getFactory(shapeString4); // Gets specified factory
		Shape shape4 = factory4.getShape(shapeString4); // Gets shape from factory
		shape4.draw(); // Displays draw message for shape

	}

}
