import cscd212_assignment4.*;

public class PizzaTestDrive {

	public static void main(String[] args) {
		PizzaStore nyStore = new NYPizzaStore();
		PizzaStore chicagoStore = new ChicagoPizzaStore();

		Pizza pizza = nyStore.orderPizza("cheese");
		System.out.println("Bob ordered a " + pizza);

		pizza = chicagoStore.orderPizza("cheese");
		System.out.println("Joe ordered a " + pizza);

		pizza = nyStore.orderPizza("pepperoni");
		System.out.println("Hannah ordered a " + pizza);

		pizza = chicagoStore.orderPizza("pepperoni");
		System.out.println("Jerry ordered a " + pizza);

		pizza = nyStore.orderPizza("veggie");
		System.out.println("Ashley ordered a " + pizza);

		pizza = chicagoStore.orderPizza("veggie");
		System.out.println("Nick ordered a " + pizza);

		pizza = nyStore.orderPizza("clam");
		System.out.println("Sarah ordered a " + pizza);

		pizza = chicagoStore.orderPizza("clam");
		System.out.println("Tommy ordered a " + pizza);

	}

}
