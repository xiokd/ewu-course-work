package cscd212_assignment4;

public class Mozzarella implements Cheese {
	public String toString() {
		return "Mozzarella";
	}
}
