package cscd212_assignment4;

public class ThickCrustDough implements Dough {
	public String toString() {
		return "Thick Crust Dough";
	}
}
