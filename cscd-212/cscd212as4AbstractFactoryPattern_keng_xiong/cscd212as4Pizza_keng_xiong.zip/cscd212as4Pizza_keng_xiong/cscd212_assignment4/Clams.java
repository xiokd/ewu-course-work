package cscd212_assignment4;

public interface Clams {
	public String toString();
}
