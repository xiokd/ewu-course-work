package cscd212_assignment4;

public interface Cheese {
	public String toString();
}
