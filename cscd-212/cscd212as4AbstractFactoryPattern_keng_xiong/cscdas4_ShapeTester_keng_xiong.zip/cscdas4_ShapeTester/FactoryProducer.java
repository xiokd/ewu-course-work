public class FactoryProducer {
	public static AbstractFactory getFactory(String shape) {
		if (shape == null) {
			return null; // Returns null if shape String is Null
		}

		AbstractFactory factory = null;

		if (shape.toLowerCase().contains("rounded")) {
			factory = new RoundedShapeFactory(); // Assigns if phrase rounded is found
		} else {
			factory = new ShapeFactory(); // Assigns if phrase is not found
		}

		return factory; // Returns factory
	}
}
