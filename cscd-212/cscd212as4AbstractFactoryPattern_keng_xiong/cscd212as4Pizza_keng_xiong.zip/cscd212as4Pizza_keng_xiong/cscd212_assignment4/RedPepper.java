package cscd212_assignment4;

public class RedPepper implements Veggies {
	public String toString() {
		return "Red Pepper";
	}
}
