package cscd212_assignment4;

public class Mushroom implements Veggies {
	public String toString() {
		return "mushroom";
	}
}
